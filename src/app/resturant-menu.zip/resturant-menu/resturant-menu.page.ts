import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import * as firebase from 'firebase';
import { RestService } from '../rest.service';
import { LoaderService } from '../loader.service';
import { AlerterrorService } from '../alerterror.service';
import { ToasterService } from '../toaster.service';
import { MenuController } from '@ionic/angular';
import { Storage } from '@ionic/storage';
@Component({
  selector: 'app-resturant-menu',
  templateUrl: './resturant-menu.page.html',
  styleUrls: ['./resturant-menu.page.scss'],
})
export class ResturantMenuPage implements OnInit {
  itemName: string = '';
  measurement: string = '';
  quantity: string = '';
  itemPrice: string = '';

  inputArray: { id: string, categoryItemValue: string , selectMeasurementValue: string,
    selectQuantityValue: string , inputPriceValue: string  , inputItemValue: string}[] = [];
  inputObj: { id: string, categoryItemValue: string , selectMeasurementValue: string,
    selectQuantityValue: string , inputPriceValue: string , inputItemValue: string };


  inputArrayBool: boolean = true;

  paymentSetup: any;
  resturantSetup: any;
  imageArray: any;
  userId: string = '';
  restaurant_data: any;
  category: any;
  resaturant_id: any;

  responseCat: any;

  constructor(public activatedRoute: ActivatedRoute,
    public restService: RestService,
    public loader: LoaderService,
    public alertService: AlerterrorService,
    public toastService: ToasterService,
    public menuCtrl: MenuController,
    private storage: Storage,
    public router: Router) {
   //addSingleitem
  }

  ionViewWillEnter(){
    var categories = JSON.stringify({
      requestType: 'all',
      
    });
    this.restService.getMenuCategories().subscribe(response => {
      console.log(response);
      this.category = JSON.parse(response['_body']);
      //this.responseCat = response;
      console.log(this.category);
      this.category = this.category.category_data;
      console.log(this.category);
    },err => {
      this.alertService.presentAlertService(err);
    });
  }
  ngOnInit() {
    this.activatedRoute.queryParams.subscribe((res)=>{
      this.paymentSetup = res.paymentSetup;
      this.resturantSetup = res.resturantSetup;
      this.imageArray = res.imageArray;
      console.log(this.resturantSetup);
     
  });
  
  var categories = JSON.stringify({
    requestType: 'all',
    
  });
  this.restService.getMenuCategories().subscribe(response => {
    console.log(response);
    this.category = JSON.parse(response['_body']);
    //this.responseCat = response;
    console.log(this.category);
    this.category = this.category.category_data;
    console.log(this.category);
  },err => {
    this.alertService.presentAlertService(err);
  });
  
    this.addInput();
  }
  i: any = 0;
  addInput(){
    this.inputObj = {
      id: '',
      categoryItemValue: '' , 
      selectMeasurementValue: '',
      selectQuantityValue: '' , 
      inputPriceValue: '',
      inputItemValue: ''
    }
    this.inputObj.id = this.i;  
    this.inputArray.push(this.inputObj);
    this.i++;
    if(this.inputArray.length == 3){
      this.inputArrayBool = false;
    }else {
      this.inputArrayBool = true;
    }
    console.log(this.inputArray);
  }
  removeInput(input , i){
    console.log(input);
    this.inputArray.splice(i , 1);
    console.log(this.inputArray);
    if(this.inputArray.length == 3){
      this.inputArrayBool = false;
    }else {
      this.inputArrayBool = true;
    }
  }
  continue(){
    this.userId = firebase.auth().currentUser.uid;
    var stringy = JSON.stringify({
      resturantSetup: this.resturantSetup,
      paymentSetup: this.paymentSetup,
      imageArray: this.imageArray,
      inputArray: this.inputArray,
      userID: this.userId
    });
    this.loader.presentLoader();
    this.restService.createRestaurantCall(stringy).subscribe(response => {
      this.restaurant_data = JSON.parse(response['_body']);
      console.log(this.restaurant_data);
      firebase.database().ref('resturantSetupData/' + this.userId ).set({
        restaurantExist: 'Exist',
        restaurant_id: this.restaurant_data.restaurant_id
      }).then(()=>{
        //success
        
      });
      this.router.navigate(['/congrats']); 
      this.loader.hideLoader();
    },err => {
      this.loader.hideLoader();
      this.alertService.presentAlertService(err);
    });
    console.log(stringy);
    /*this.inputObj = {
      id: '',
      inputItemValue: '' , 
      selectMeasurementValue: '',
      selectQuantityValue: '' , 
      inputPriceValue: ''
    };
    this.inputObj.inputItemValue = this.itemName;
    this.inputObj.selectMeasurementValue = this. measurement;
    this.inputObj.selectQuantityValue = this.quantity;
    this.inputObj.inputPriceValue = this.itemPrice;
    this.inputArray.push(this.inputObj);*/
    //console.log(this.inputArray);
    //alert(this.inputArray);
   /* var stringy = JSON.stringify({
      paymentSetup: this.paymentSetup,
      resturantSetup: this.resturantSetup,
      imageArray: this.imageArray,
      inputArray: this.inputArray
    });
    this.userId = firebase.auth().currentUser.uid;
    this.restService.UpdateProfile().subscribe(response => {
      
    } , err => {
      console.log(err);
    })
    firebase.database().ref('resturantSetupData/' + this.userId ).set({
      resturantExist: 'Exist'
    
    }).then(()=>{
      //success
      
    });*/
  }
  submitItemData(){
    this.storage.get('user_accounts_id').then(user_accounts_id => {
      this.storage.get('restaurants_id').then(restaurant_id => {
          this.resaturant_id =restaurant_id;
     
          this.userId = user_accounts_id;
          var stringy = JSON.stringify({
            requestType : 'save',
            inputArray: this.inputArray, 
            resturantId: this.resaturant_id,
            userID: this.userId
          });
          this.loader.presentLoader();
          this.restService.savemultipleItems(stringy).subscribe(response => {
            this.restaurant_data = JSON.parse(response['_body']);
            console.log(this.restaurant_data);
            
            this.router.navigate(['/resturant-menu']); 
            this.loader.hideLoader();
          },err => {
            this.loader.hideLoader();
            this.alertService.presentAlertService(err);
          });
      }); 
    });
  }
  toggleMenu(){
    this.menuCtrl.toggle();
  }
}
